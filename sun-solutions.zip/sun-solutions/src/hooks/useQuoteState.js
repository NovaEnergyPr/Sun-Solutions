import { useState, useMemo, useCallback } from 'react';
import {
  resolvePanelCount,
  resolveBatteryForPanels,
  maxExpansions,
  clampCommission,
  calculateAll,
} from '../utils/calculations';
import { PANEL_RULES } from '../config';

const DEFAULTS = {
  product:         'sunrun',
  projectType:     'residential_sunrun',
  sellerPosition:  'closer',
  pricingVersion:  '2026-Q1',
  location:        'puerto_rico',
  panels:          10,
  panelType:       'qcells_410',
  batteryType:     'none',
  batteryCount:    1,
  expansionCount:  0,
  roofType:        'cemento',
  electricalIssues: false,
  lowFICO:         false,
  commissionPct:   12,
  soldPPW:         '',
};

export function useQuoteState() {
  const [state, setState] = useState(DEFAULTS);

  const update = useCallback((key, value) => {
    setState(prev => {
      let next = { ...prev, [key]: value };

      // Panel count logic
      if (key === 'panels') {
        const resolved = resolvePanelCount(value);
        next.panels = resolved;

        // Battery forced for large systems
        const { batteryType, batteryCount, locked } = resolveBatteryForPanels(
          resolved, next.batteryType, next.batteryCount
        );
        next.batteryType  = batteryType;
        next.batteryCount = batteryCount;
        next.batteryLocked = locked;

        // Clamp expansions
        const maxExp = maxExpansions(resolved);
        if (next.expansionCount > maxExp) next.expansionCount = maxExp;
      }

      // Battery type change
      if (key === 'batteryType') {
        if (value === 'none') next.batteryCount = 1;
      }

      // Product change
      if (key === 'product') {
        const map = {
          sunrun:     'residential_sunrun',
          lightreach: 'residential_lightreach',
          cash:       'cash_financiamiento',
        };
        next.projectType = map[value] ?? next.projectType;
      }

      // Commission clamp
      if (key === 'commissionPct') {
        next.commissionPct = clampCommission(value);
      }

      return next;
    });
  }, []);

  const reset = useCallback(() => setState(DEFAULTS), []);

  const results = useMemo(() => calculateAll(state), [state]);

  const batteryLocked =
    state.panels >= 44 && state.batteryType !== 'none';

  const maxExp = maxExpansions(state.panels);

  return { state, update, reset, results, batteryLocked, maxExp };
}

// ============================================================
// SUN SOLUTIONS — CENTRAL CONFIGURATION
// All prices, rules, and tables live here.
// Update this file to change pricing without touching components.
// ============================================================

export const PANEL_WATTAGE = 410; // Watts per panel

// ── Products / Programs ─────────────────────────────────────
export const PRODUCTS = {
  sunrun: {
    id: 'sunrun',
    label: 'Sunrun',
    epcRate: 2.50,          // $ per watt — commissionable base
    currency: 'USD',
    supportsMonthlyPayment: false,
    description: 'Sunrun Power Purchase Agreement',
  },
  lightreach: {
    id: 'lightreach',
    label: 'LightReach',
    epcRate: 2.50,
    currency: 'USD',
    supportsMonthlyPayment: true,
    description: 'LightReach Lease Program',
  },
  cash: {
    id: 'cash',
    label: 'Cash / Financing',
    epcRate: 2.50,
    currency: 'USD',
    supportsMonthlyPayment: false,
    description: 'Cash Purchase or Third-Party Financing',
  },
};

// ── Project Types ────────────────────────────────────────────
export const PROJECT_TYPES = [
  { value: 'residential_sunrun',     label: 'Residencial Sunrun' },
  { value: 'residential_lightreach', label: 'Residencial LightReach' },
  { value: 'cash_financiamiento',    label: 'Cash / Financiamiento' },
];

// ── Seller Positions ─────────────────────────────────────────
export const SELLER_POSITIONS = [
  { value: 'setter',    label: 'Setter' },
  { value: 'closer',   label: 'Closer' },
  { value: 'manager',  label: 'Manager' },
  { value: 'director', label: 'Director' },
];

// ── Pricing Versions ─────────────────────────────────────────
export const PRICING_VERSIONS = [
  { value: '2026-Q1', label: '2026-Q1' },
  { value: '2026-Q2', label: '2026-Q2' },
  { value: '2026-Q3', label: '2026-Q3' },
];

// ── Locations & Adders ───────────────────────────────────────
export const LOCATIONS = {
  puerto_rico: { label: 'Puerto Rico', adder: 0 },
  vieques:     { label: 'Vieques',     adder: 0 }, // update when pricing is available
  culebra:     { label: 'Culebra',     adder: 0 }, // update when pricing is available
};

// ── Panel Types ──────────────────────────────────────────────
export const PANEL_TYPES = [
  { value: 'qcells_410', label: 'QCells 410', wattage: 410 },
];

// ── Battery Pricing ──────────────────────────────────────────
// NOT commissionable
export const BATTERY_CONFIG = {
  none: { label: 'None', price: 0, count: 0 },
  pw3_hybrid: {
    label: 'PW3 Hybrid',
    pricePerUnit: {
      1: 10500,
      2: 20000,
    },
  },
};

// Panels >= 44 force 2x PW3 Hybrid (locked)
export const LARGE_SYSTEM_THRESHOLD = 44;
export const LARGE_SYSTEM_FORCED_BATTERIES = 2;

// ── Expansion Battery Pricing ────────────────────────────────
// NOT commissionable
export const EXPANSION_CONFIG = {
  priceEach: 7000,
  maxForSmallSystem: 3,  // panels < 37
  maxForLargeSystem: 2,  // panels >= 44
};

// ── Roof Type Adders ─────────────────────────────────────────
// NOT commissionable — values = 0 until pricing is confirmed
export const ROOF_TYPES = {
  cemento:  { label: 'Cemento',  adder: 0 },
  galvalum: { label: 'Galvalum', adder: 0 },
};

// ── Non-Commissionable Adders ────────────────────────────────
export const ADDERS = {
  electrical_issues: {
    label: 'Electrical Issues',
    price: 2000,
    commissionable: false,
  },
  low_fico: {
    label: 'Low FICO',
    price: 1000,
    commissionable: false,
  },
};

// ── Commission Override Table ────────────────────────────────
// commission% → override%
// Formula: if <= 12: commission × 5; if > 12: 60 + (commission - 12) × 5
export const OVERRIDE_TABLE = {
  6:  30,
  7:  35,
  8:  40,
  9:  45,
  10: 50,
  11: 55,
  12: 60,
  13: 65,
  14: 70,
  15: 75,
  16: 80,
  17: 85,
};

export const COMMISSION_MIN = 6;
export const COMMISSION_MAX = 16;

// ── LightReach Mock Payment Table ────────────────────────────
// Key = system size kW (string), value = estimated monthly payment $
// Replace with real table or PDF-parsed data when available
export const LIGHTREACH_PAYMENT_TABLE = {
  '3.28': 118,
  '4.10': 148,
  '4.92': 177,
  '5.33': 194,
  '5.74': 208,
  '6.15': 221,
  '6.56': 237,
  '6.97': 251,
  '7.38': 266,
  '7.79': 281,
  '8.20': 296,
  '8.61': 311,
  '9.02': 325,
  '9.43': 340,
  '9.84': 355,
  '10.25': 370,
  '10.66': 384,
  '11.07': 399,
  '11.48': 413,
  '11.89': 428,
  '12.30': 443,
  '13.12': 472,
  '14.76': 531,
  '16.40': 590,
  '18.04': 649,
};

// ── Panel Count Rules ────────────────────────────────────────
export const PANEL_RULES = {
  min: 1,
  blockedMin: 37,
  blockedMax: 43,
  jumpTo: 44,
};

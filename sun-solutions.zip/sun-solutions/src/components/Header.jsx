import React from 'react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-[#0f172a]/95 backdrop-blur-md border-b border-[#2d3f55]">
      <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Sun icon */}
          <div className="relative w-9 h-9 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-[#f4b63f]/20 animate-pulse-slow" />
            <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 relative">
              <circle cx="18" cy="18" r="7" fill="#f4b63f" />
              {[0, 45, 90, 135, 180, 225, 270, 315].map((deg, i) => (
                <line
                  key={i}
                  x1="18" y1="18"
                  x2={18 + 13 * Math.cos((deg * Math.PI) / 180)}
                  y2={18 + 13 * Math.sin((deg * Math.PI) / 180)}
                  stroke="#f4b63f"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  opacity={i % 2 === 0 ? 1 : 0.5}
                />
              ))}
            </svg>
          </div>

          <div>
            <h1 className="font-display font-bold text-lg leading-none tracking-wide text-[#f8fafc]">
              SUN SOLUTIONS
            </h1>
            <p className="text-[10px] font-body tracking-widest text-[#f4b63f] uppercase mt-0.5">
              Quotes & Commissions
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="hidden sm:flex items-center gap-1.5 text-xs font-body text-[#64748b] bg-[#1e293b] border border-[#2d3f55] rounded-full px-3 py-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live
          </span>
          <span className="text-xs font-mono text-[#4b5563]">v1.0</span>
        </div>
      </div>
    </header>
  );
}

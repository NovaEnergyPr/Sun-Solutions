import React from 'react';
import { SectionCard, Select } from '../ui';
import { PRODUCTS, PROJECT_TYPES, SELLER_POSITIONS, PRICING_VERSIONS, LOCATIONS } from '../../config';

const productOptions  = Object.values(PRODUCTS).map(p => ({ value: p.id, label: p.label }));
const locationOptions = Object.entries(LOCATIONS).map(([k, v]) => ({ value: k, label: v.label }));

export function GeneralInfo({ state, update }) {
  return (
    <SectionCard title="General Information" icon="🏢">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Select
          label="Product / Program"
          value={state.product}
          onChange={v => update('product', v)}
          options={productOptions}
        />
        <Select
          label="Project Type"
          value={state.projectType}
          onChange={v => update('projectType', v)}
          options={PROJECT_TYPES}
        />
        <Select
          label="Seller Position"
          value={state.sellerPosition}
          onChange={v => update('sellerPosition', v)}
          options={SELLER_POSITIONS}
        />
        <Select
          label="Pricing Version"
          value={state.pricingVersion}
          onChange={v => update('pricingVersion', v)}
          options={PRICING_VERSIONS}
        />
        <Select
          label="Location"
          hint="Location adders auto-apply"
          value={state.location}
          onChange={v => update('location', v)}
          options={locationOptions}
        />
      </div>
    </SectionCard>
  );
}

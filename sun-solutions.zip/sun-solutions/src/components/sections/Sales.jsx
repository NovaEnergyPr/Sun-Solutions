import React from 'react';
import { SectionCard, NumberInput, InfoRow } from '../ui';
import { COMMISSION_MIN, COMMISSION_MAX } from '../../config';
import { fmt } from '../../utils/format';

export function Sales({ state, update, results }) {
  return (
    <SectionCard title="Sales" icon="💼">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <NumberInput
          label="Commission Percentage"
          hint={`Range: ${COMMISSION_MIN}% – ${COMMISSION_MAX}%`}
          value={state.commissionPct}
          onChange={v => update('commissionPct', v)}
          min={COMMISSION_MIN}
          max={COMMISSION_MAX}
          step={1}
          suffix="%"
        />

        <NumberInput
          label="Sold PPW"
          hint="Price per watt — manual entry"
          value={state.soldPPW}
          onChange={v => update('soldPPW', v)}
          step={0.001}
          prefix="$"
        />
      </div>

      {/* Override table callout */}
      <div className="mt-3 rounded-xl bg-[#0b2e83]/15 border border-[#0b2e83]/30 px-4 py-3">
        <p className="text-[9px] uppercase tracking-widest text-[#64748b] mb-2">Commission → Override Lookup</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
          {[6,7,8,9,10,11,12,13,14,15,16].map(pct => {
            const override = pct <= 12 ? pct * 5 : 60 + (pct - 12) * 5;
            const isActive = pct === state.commissionPct;
            return (
              <div
                key={pct}
                className={`flex justify-between items-center py-0.5 px-2 rounded text-[11px] transition-all ${
                  isActive
                    ? 'bg-[#f4b63f]/20 text-[#f4b63f] font-semibold'
                    : 'text-[#64748b]'
                }`}
              >
                <span className="font-mono">{pct}%</span>
                <span className="font-mono">→ {override}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live preview */}
      {state.soldPPW && (
        <div className="mt-3 rounded-xl bg-[#1a2740] border border-[#2d3f55] px-4 py-3 space-y-1">
          <p className="text-[9px] uppercase tracking-widest text-[#4b5563] mb-2">Sales Preview</p>
          <InfoRow label="Sold PPW" value={fmt.ppw(state.soldPPW)} />
          <InfoRow label="Sold Total" value={fmt.currency(results.soldTotal)} />
          <InfoRow label="Excedente (Sold − System)" value={fmt.currency(results.excedente)} />
          <InfoRow label="Override %" value={fmt.pct(results.overridePct)} />
        </div>
      )}
    </SectionCard>
  );
}

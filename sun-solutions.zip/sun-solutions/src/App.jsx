import React from 'react';
import { Header } from './components/Header';
import { GeneralInfo } from './components/sections/GeneralInfo';
import { Panels } from './components/sections/Panels';
import { Storage } from './components/sections/Storage';
import { Adders } from './components/sections/Adders';
import { Sales } from './components/sections/Sales';
import { Results } from './components/sections/Results';
import { useQuoteState } from './hooks/useQuoteState';

export default function App() {
  const { state, update, reset, results, batteryLocked, maxExp } = useQuoteState();

  return (
    <div className="min-h-screen bg-[#0f172a] text-[#f8fafc] font-body">
      <Header />

      <main className="max-w-4xl mx-auto px-4 py-6 space-y-4">
        {/* Reset button */}
        <div className="flex justify-end">
          <button
            onClick={reset}
            className="text-xs font-body text-[#64748b] hover:text-[#94a3b8] border border-[#2d3f55] hover:border-[#4b5563] rounded-full px-4 py-1.5 transition-all duration-150"
          >
            Reset Quote
          </button>
        </div>

        <GeneralInfo state={state} update={update} />
        <Panels state={state} update={update} />
        <Storage state={state} update={update} batteryLocked={batteryLocked} maxExp={maxExp} />
        <Adders state={state} update={update} results={results} />
        <Sales state={state} update={update} results={results} />
        <Results results={results} state={state} />

        {/* Footer */}
        <div className="text-center py-6 text-[10px] text-[#334155] font-body tracking-widest uppercase">
          Sun Solutions © 2026 — Quotes & Commissions Engine
        </div>
      </main>
    </div>
  );
}
